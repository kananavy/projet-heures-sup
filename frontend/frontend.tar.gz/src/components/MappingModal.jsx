import React, { useState, useEffect } from 'react';
import Modal from './ui/Modal';
import { LoadingSpinner } from './ui/Loading';

export default function MappingModal({ 
  show, 
  headers = [], 
  sampleRows = [], 
  targetFields = [], 
  onCancel, 
  onConfirm,
  loading = false 
}) {
  const [mapping, setMapping] = useState({});

  useEffect(() => {
    if (show && targetFields.length > 0) {
      // Initialiser le mapping
      const init = {};
      targetFields.forEach(field => {
        init[field.key] = "";
      });
      
      // Essayer de mapper automatiquement basé sur les noms
      targetFields.forEach(field => {
        const fieldLower = field.label.toLowerCase();
        const matchingHeader = headers.find(header => {
          const headerLower = header.toLowerCase();
          return (
            headerLower.includes(fieldLower) ||
            fieldLower.includes(headerLower) ||
            (field.key.includes('nom') && headerLower.includes('nom')) ||
            (field.key.includes('date') && headerLower.includes('date')) ||
            (field.key.includes('heure') && headerLower.includes('heure')) ||
            (field.key.includes('mention') && headerLower.includes('mention')) ||
            (field.key.includes('duree') && headerLower.includes('durée'))
          );
        });
        if (matchingHeader) {
          init[field.key] = matchingHeader;
        }
      });
      
      setMapping(init);
    }
  }, [show, headers, targetFields]);

  if (!show) return null;

  const handleMappingChange = (fieldKey, headerValue) => {
    setMapping(prev => ({
      ...prev,
      [fieldKey]: headerValue
    }));
  };

  const getMappingStats = () => {
    const mappedCount = Object.values(mapping).filter(value => value !== "").length;
    const totalCount = targetFields.length;
    return { mappedCount, totalCount };
  };

  const stats = getMappingStats();

  const footer = (
    <>
      <button
        onClick={onCancel}
        className="btn btn-outline"
        disabled={loading}
      >
        Annuler
      </button>
      <button
        onClick={() => onConfirm(mapping)}
        className="btn btn-success"
        disabled={loading}
      >
        {loading ? (
          <>
            <LoadingSpinner size="sm" />
            Importation...
          </>
        ) : (
          <>
            <i className="bi bi-upload"></i>
            Importer ({stats.mappedCount}/{stats.totalCount} colonnes)
          </>
        )}
      </button>
    </>
  );

  return (
    <Modal
      isOpen={show}
      onClose={onCancel}
      title="Mappage des colonnes"
      size="xl"
      footer={footer}
      closeOnOverlayClick={!loading}
    >
      <div className="space-y-xl">
        {/* Statistiques de mappage */}
        <div className="modern-card">
          <div className="modern-card-body">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-lg">Configuration du mappage</h4>
                <p className="text-gray-600 text-sm mt-sm">
                  Associez chaque champ de destination à une colonne de votre fichier Excel
                </p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-primary">
                  {stats.mappedCount}/{stats.totalCount}
                </div>
                <div className="text-sm text-gray-500">colonnes mappées</div>
              </div>
            </div>
            
            {/* Barre de progression */}
            <div className="mt-lg">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-primary-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(stats.mappedCount / stats.totalCount) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Configuration du mappage */}
        <div className="modern-card">
          <div className="modern-card-header">
            <h4 className="modern-card-title">
              <i className="bi bi-arrow-down-up"></i>
              Mappage des colonnes
            </h4>
          </div>
          <div className="modern-card-body">
            <div className="form-grid form-grid-2">
              {targetFields.map(targetField => (
                <div key={targetField.key} className="form-group">
                  <label className="form-label">
                    {targetField.label}
                    {targetField.required && <span className="text-error ml-1">*</span>}
                  </label>
                  <select
                    className="form-select"
                    value={mapping[targetField.key] || ""}
                    onChange={(e) => handleMappingChange(targetField.key, e.target.value)}
                    disabled={loading}
                  >
                    <option value="">-- ne pas mapper --</option>
                    {headers.map(header => (
                      <option key={header} value={header}>
                        {header}
                      </option>
                    ))}
                  </select>
                  {mapping[targetField.key] && (
                    <div className="mt-xs">
                      <span className="badge badge-success text-xs">
                        <i className="bi bi-check-circle"></i>
                        Mappé avec "{mapping[targetField.key]}"
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Aperçu des données */}
        <div className="modern-card">
          <div className="modern-card-header">
            <h4 className="modern-card-title">
              <i className="bi bi-table"></i>
              Aperçu des données (5 premières lignes)
            </h4>
          </div>
          <div className="modern-card-body">
            <div style={{ 
              maxHeight: '300px', 
              overflowY: 'auto',
              overflowX: 'auto'
            }}>
              <table className="table">
                <thead>
                  <tr>
                    {headers.map(header => (
                      <th key={header} style={{ minWidth: '120px' }}>
                        <div>
                          <div className="font-semibold">{header}</div>
                          {/* Indication si la colonne est mappée */}
                          {Object.values(mapping).includes(header) && (
                            <div className="mt-xs">
                              <span className="badge badge-primary text-xs">
                                <i className="bi bi-link-45deg"></i>
                                Mappée
                              </span>
                            </div>
                          )}
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sampleRows.slice(0, 5).map((row, index) => (
                    <tr key={index}>
                      {headers.map(header => (
                        <td key={header} style={{ maxWidth: '150px' }}>
                          <div className="text-sm" title={String(row[header] ?? "")}>
                            {String(row[header] ?? "").substring(0, 50)}
                            {String(row[header] ?? "").length > 50 && "..."}
                          </div>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Avertissements */}
        {stats.mappedCount < stats.totalCount && (
          <div className="modern-card">
            <div className="modern-card-body">
              <div className="flex items-start gap-md">
                <i className="bi bi-exclamation-triangle text-warning text-lg"></i>
                <div>
                  <h5 className="font-semibold text-warning">Colonnes non mappées</h5>
                  <p className="text-sm text-gray-600 mt-sm">
                    {stats.totalCount - stats.mappedCount} colonne(s) ne sont pas associées. 
                    Ces champs resteront vides lors de l'importation.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}