import React, { useState } from 'react';
import api from '../config/api';
import MappingModal from './MappingModal';
import { LoadingSpinner } from './ui/Loading';

export default function ImportPanel({ onImported, addNotification }) {
  const [mode, setMode] = useState("teachers");
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [createMissing, setCreateMissing] = useState(true);
  const [importResult, setImportResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const targetFieldsByMode = {
    teachers: [
      { key: "enseignantCol", label: "Enseignants (nom)" },
      { key: "mentionCol", label: "Mention" },
      { key: "parcoursCol", label: "Parcours" },
      { key: "niveauCol", label: "Niveau" },
      { key: "ueCol", label: "UE" },
      { key: "ecCol", label: "EC" },
      { key: "volumeCol", label: "Volume horaire" }
    ],
    courses: [
      { key: "typeCol", label: "TYPE" },
      { key: "dateCol", label: "Date (jj/mm/aaaa)" },
      { key: "startCol", label: "Heure début (hh:mm)" },
      { key: "endCol", label: "Heure fin (hh:mm)" },
      { key: "mentionCol", label: "Mention" },
      { key: "parcoursCol", label: "Parcours" },
      { key: "niveauCol", label: "Niveau" },
      { key: "ueCol", label: "UE" },
      { key: "ecCol", label: "EC" },
      { key: "enseignantCol", label: "Enseignant (nom)" },
      { key: "dureeCol", label: "Durée (heures)" }
    ]
  };

  const handlePreview = async () => {
    if (!file) {
      addNotification("Veuillez choisir un fichier Excel", 'warning');
      return;
    }

    setLoading(true);
    const fd = new FormData();
    fd.append("file", file);
    
    try {
      const res = await api.post(`/import/${mode}/preview`, fd, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      setPreview(res.data);
      setShowModal(true);
    } catch (err) {
      console.error('Erreur preview:', err);
      addNotification(
        err.response?.data?.message || 'Erreur lors de l\'aperçu du fichier',
        'error'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleImport = async (mapping) => {
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("mapping", JSON.stringify(mapping));
      if (mode === "courses") {
        fd.append("createMissing", createMissing ? "true" : "false");
      }

      const res = await api.post(`/import/${mode}`, fd, {
        headers: { "Content-Type": "multipart/form-data" }
      });

      setImportResult(res.data);
      setShowModal(false);
      setFile(null);
      setPreview(null);
      
      if (onImported) onImported();
      
      addNotification(
        `Importation réussie: ${res.data.summary}`,
        'success'
      );

    } catch (err) {
      console.error('Erreur import:', err);
      addNotification(
        err.response?.data?.message || 'Erreur lors de l\'importation',
        'error'
      );
    } finally {
      setLoading(false);
    }
  };

  const closeResult = () => {
    setImportResult(null);
  };

  const modeOptions = [
    { value: 'teachers', label: 'Enseignants', icon: '👨‍🏫' },
    { value: 'courses', label: 'Cours', icon: '📚' }
  ];

  return (
    <div className="modern-card">
      <div className="modern-card-header">
        <h3 className="modern-card-title">
          <i className="bi bi-file-earmark-excel"></i>
          Importation Excel
        </h3>
      </div>

      <div className="modern-card-body">
        <div className="space-y-lg">
          {/* Sélection du mode */}
          <div className="form-group">
            <label className="form-label">Type d'import</label>
            <select
              className="form-select"
              value={mode}
              onChange={(e) => setMode(e.target.value)}
              disabled={loading}
            >
              {modeOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.icon} {option.label}
                </option>
              ))}
            </select>
          </div>

          {/* Sélection du fichier */}
          <div className="form-group">
            <label className="form-label">Fichier Excel</label>
            <input
              type="file"
              accept=".xls,.xlsx"
              className="form-input"
              onChange={(e) => setFile(e.target.files[0])}
              disabled={loading}
            />
            <p className="text-xs text-gray-500 mt-sm">
              Formats acceptés: .xls, .xlsx
            </p>
          </div>

          {/* Option pour les cours */}
          {mode === "courses" && (
            <div className="form-group">
              <label className="flex items-center gap-sm">
                <input
                  type="checkbox"
                  checked={createMissing}
                  onChange={(e) => setCreateMissing(e.target.checked)}
                  disabled={loading}
                />
                <span className="form-label mb-0">
                  Créer automatiquement les enseignants manquants
                </span>
              </label>
              <p className="text-xs text-gray-500 mt-sm">
                Si activé, les enseignants non trouvés seront créés automatiquement
              </p>
            </div>
          )}

          {/* Bouton d'aperçu */}
          <button
            onClick={handlePreview}
            disabled={!file || loading}
            className="btn btn-primary w-full"
          >
            {loading ? (
              <>
                <LoadingSpinner size="sm" />
                Analyse en cours...
              </>
            ) : (
              <>
                <i className="bi bi-eye"></i>
                Aperçu et mappage des colonnes
              </>
            )}
          </button>
        </div>

        {/* Résultats d'importation */}
        {importResult && (
          <div className="modern-card mt-lg">
            <div className="modern-card-header">
              <div className="flex items-center justify-between">
                <h4 className="modern-card-title text-lg">
                  <i className="bi bi-check-circle text-success"></i>
                  Résultat de l'importation
                </h4>
                <button
                  onClick={closeResult}
                  className="btn btn-ghost btn-sm"
                >
                  <i className="bi bi-x-lg"></i>
                </button>
              </div>
            </div>
            
            <div className="modern-card-body">
              <div className="space-y-md">
                <div className="text-lg font-semibold text-success">
                  {importResult.summary}
                </div>

                {mode === "teachers" && (
                  <div className="form-grid form-grid-2">
                    <div className="stat-card success">
                      <div className="stat-header">
                        <h5 className="stat-title">Créés</h5>
                        <span className="stat-icon">✅</span>
                      </div>
                      <p className="stat-value">{importResult.createdCount}</p>
                      <p className="stat-subtitle">nouveaux enseignants</p>
                    </div>
                    <div className="stat-card warning">
                      <div className="stat-header">
                        <h5 className="stat-title">Mis à jour</h5>
                        <span className="stat-icon">🔄</span>
                      </div>
                      <p className="stat-value">{importResult.updatedCount}</p>
                      <p className="stat-subtitle">enseignants modifiés</p>
                    </div>
                  </div>
                )}

                {mode === "courses" && (
                  <div className="form-grid form-grid-2">
                    <div className="stat-card success">
                      <div className="stat-header">
                        <h5 className="stat-title">Cours créés</h5>
                        <span className="stat-icon">📚</span>
                      </div>
                      <p className="stat-value">{importResult.createdCount}</p>
                      <p className="stat-subtitle">nouveaux cours</p>
                    </div>
                    {importResult.errorCount > 0 && (
                      <div className="stat-card error">
                        <div className="stat-header">
                          <h5 className="stat-title">Erreurs</h5>
                          <span className="stat-icon">❌</span>
                        </div>
                        <p className="stat-value">{importResult.errorCount}</p>
                        <p className="stat-subtitle">cours non importés</p>
                      </div>
                    )}
                  </div>
                )}

                <div className="text-sm text-gray-600">
                  <strong>Total traité:</strong> {importResult.totalRows} ligne(s)
                  {importResult.skippedCount > 0 && (
                    <>
                      {' • '}
                      <strong>Ignorées:</strong> {importResult.skippedCount} ligne(s)
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modal de mappage */}
      {preview && showModal && (
        <MappingModal
          show={showModal}
          headers={preview.headers}
          sampleRows={preview.rows}
          targetFields={targetFieldsByMode[mode]}
          onCancel={() => setShowModal(false)}
          onConfirm={handleImport}
          loading={loading}
        />
      )}
    </div>
  );
}