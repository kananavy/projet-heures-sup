import React from 'react';

export default function StatsCard({ 
  title, 
  value, 
  subtitle, 
  icon, 
  type = 'primary',
  trend,
  className = '' 
}) {
  return (
    <div className={`stat-card ${type} ${className}`}>
      <div className="stat-header">
        <h3 className="stat-title">{title}</h3>
        {icon && <span className="stat-icon">{icon}</span>}
      </div>
      
      <div className="flex items-end justify-between">
        <div>
          <p className="stat-value">{value}</p>
          {subtitle && <p className="stat-subtitle">{subtitle}</p>}
        </div>
        
        {trend && (
          <div className={`flex items-center gap-sm text-xs ${
            trend.type === 'up' ? 'text-success' : 
            trend.type === 'down' ? 'text-error' : 'text-gray-500'
          }`}>
            <i className={`bi bi-arrow-${
              trend.type === 'up' ? 'up' : 
              trend.type === 'down' ? 'down' : 'right'
            }`}></i>
            <span className="font-medium">{trend.value}</span>
          </div>
        )}
      </div>
    </div>
  );
}