import React, { useState, useEffect } from 'react';
import './index.css';

// Hooks
import { useNotifications } from './hooks/useNotifications';

// API
import api from './config/api';

// Composants
import TeacherForm from './components/TeacherForm';
import TeacherList from './components/TeacherList';
import CourseForm from './components/CourseForm';
import ImportPanel from './components/ImportPanel';
import TeacherDetailModal from './components/TeacherDetailModal';
import StatsCards from './components/StatsCards';
import NotificationSystem from './components/ui/NotificationSystem';
import Loading from './components/ui/Loading';

export default function App() {
  const [teachers, setTeachers] = useState([]);
  const [selectedTeacher, setSelectedTeacher] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  
  const { 
    notifications, 
    success, 
    error, 
    warning, 
    info, 
    removeNotification 
  } = useNotifications();

  // Charger les enseignants
  const loadTeachers = async () => {
    try {
      setLoading(true);
      const res = await api.get('/enseignants');
      setTeachers(res.data);
    } catch (err) {
      console.error('Erreur chargement enseignants:', err);
      error('Erreur lors du chargement des enseignants');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTeachers();
  }, []);

  // Configuration des onglets
  const tabs = [
    { 
      id: 'overview', 
      label: 'Vue d\'ensemble', 
      icon: 'bi-speedometer2',
      description: 'Statistiques et aperçu général'
    },
    { 
      id: 'teachers', 
      label: 'Enseignants', 
      icon: 'bi-people',
      description: 'Gestion des enseignants'
    },
    { 
      id: 'courses', 
      label: 'Cours', 
      icon: 'bi-calendar-event',
      description: 'Ajout de cours'
    },
    { 
      id: 'import', 
      label: 'Importation', 
      icon: 'bi-file-earmark-excel',
      description: 'Import Excel'
    }
  ];

  // Rendu du contenu selon l'onglet actif
  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-xl">
            <StatsCards teachers={teachers} />
            
            {/* Actions rapides */}
            <div className="form-grid form-grid-2">
              <TeacherForm 
                onSaved={loadTeachers} 
                addNotification={success}
              />
              <CourseForm 
                teachers={teachers} 
                onSaved={loadTeachers} 
                addNotification={success}
              />
            </div>
          </div>
        );

      case 'teachers':
        return (
          <div className="space-y-xl">
            <div className="form-grid form-grid-1">
              <TeacherForm 
                onSaved={loadTeachers} 
                addNotification={success}
              />
            </div>
            <TeacherList 
              teachers={teachers} 
              onSelect={setSelectedTeacher}
              onRefresh={loadTeachers}
              addNotification={success}
            />
          </div>
        );

      case 'courses':
        return (
          <div className="space-y-xl">
            <CourseForm 
              teachers={teachers} 
              onSaved={loadTeachers} 
              addNotification={success}
            />
            {teachers.length === 0 && (
              <div className="modern-card">
                <div className="modern-card-body text-center py-3xl">
                  <div className="text-6xl mb-lg">👨‍🏫</div>
                  <h4 className="text-xl font-semibold text-gray-700 mb-sm">
                    Aucun enseignant disponible
                  </h4>
                  <p className="text-gray-500 mb-lg">
                    Vous devez d'abord ajouter des enseignants pour pouvoir créer des cours
                  </p>
                  <button
                    onClick={() => setActiveTab('teachers')}
                    className="btn btn-primary"
                  >
                    <i className="bi bi-person-plus"></i>
                    Ajouter un enseignant
                  </button>
                </div>
              </div>
            )}
          </div>
        );

      case 'import':
        return (
          <div className="space-y-xl">
            <ImportPanel 
              onImported={loadTeachers} 
              addNotification={success}
            />
            
            {/* Aide pour l'importation */}
            <div className="modern-card">
              <div className="modern-card-header">
                <h4 className="modern-card-title">
                  <i className="bi bi-info-circle"></i>
                  Guide d'importation
                </h4>
              </div>
              <div className="modern-card-body">
                <div className="space-y-md">
                  <div>
                    <h5 className="font-semibold mb-sm">📋 Format des fichiers Excel</h5>
                    <ul className="text-sm text-gray-600 space-y-xs">
                      <li>• Utilisez des fichiers .xls ou .xlsx</li>
                      <li>• La première ligne doit contenir les en-têtes</li>
                      <li>• Évitez les cellules fusionnées</li>
                      <li>• Une seule feuille sera lue (la première)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h5 className="font-semibold mb-sm">👨‍🏫 Import des enseignants</h5>
                    <ul className="text-sm text-gray-600 space-y-xs">
                      <li>• Le nom est obligatoire</li>
                      <li>• Le volume horaire par défaut est de 24h</li>
                      <li>• Les enseignants existants seront mis à jour</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h5 className="font-semibold mb-sm">📚 Import des cours</h5>
                    <ul className="text-sm text-gray-600 space-y-xs">
                      <li>• La date et la durée sont obligatoires</li>
                      <li>• L'enseignant doit exister ou être créé automatiquement</li>
                      <li>• Format de date recommandé: JJ/MM/AAAA</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="app-container">
        <div className="flex items-center justify-center" style={{ minHeight: '60vh' }}>
          <Loading text="Chargement de l'application..." size="lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="app-container">
      {/* Système de notifications */}
      <NotificationSystem 
        notifications={notifications} 
        onRemove={removeNotification} 
      />
      
      {/* Header */}
      <header className="app-header">
        <div>
          <h1 className="app-title">
            <span className="text-4xl">🎓</span>
            Gestion des Heures d'Enseignement
          </h1>
          <p className="app-subtitle">
            Système moderne de suivi et de gestion des heures d'enseignement universitaire
          </p>
        </div>
        
        {/* Statistiques rapides dans le header */}
        <div className="flex gap-lg mt-lg">
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">{teachers.length}</div>
            <div className="text-sm text-gray-500">Enseignants</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-success">
              {teachers.reduce((sum, t) => sum + (t.heuresNormales || 0), 0)}h
            </div>
            <div className="text-sm text-gray-500">H. Normales</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-warning">
              {teachers.reduce((sum, t) => sum + (t.heuresSupplementaires || 0), 0)}h
            </div>
            <div className="text-sm text-gray-500">H. Supplémentaires</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-600">
              {teachers.reduce((sum, t) => sum + (t.cours?.length || 0), 0)}
            </div>
            <div className="text-sm text-gray-500">Cours</div>
          </div>
        </div>
      </header>

      {/* Navigation par onglets */}
      <nav className="tab-navigation">
        <div className="tab-list">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
            >
              <i className={`${tab.icon} tab-icon`}></i>
              <div className="text-left">
                <div className="font-medium">{tab.label}</div>
                <div className="text-xs text-gray-500">{tab.description}</div>
              </div>
            </button>
          ))}
        </div>
      </nav>

      {/* Contenu principal */}
      <main>
        {renderTabContent()}
      </main>

      {/* Modal détail enseignant */}
      {selectedTeacher && (
        <TeacherDetailModal
          teacher={selectedTeacher}
          onClose={() => setSelectedTeacher(null)}
          onRefresh={loadTeachers}
          addNotification={success}
        />
      )}

      {/* Footer */}
      <footer className="text-center mt-3xl py-xl">
        <div className="text-gray-500">
          <div className="font-medium mb-sm">
            Système de Gestion des Heures d'Enseignement
          </div>
          <div className="text-sm">
            © 2025 • Développé pour l'Université de Madagascar 
            • Version 2.0
          </div>
          <div className="text-xs mt-sm">
            Florent - Développeur Full Stack Laravel & React
          </div>
        </div>
      </footer>
    </div>
  );
}