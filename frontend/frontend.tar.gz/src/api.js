import axios from 'axios';

// Configuration de base de l'API
export const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8080/api';

// Instance axios configurée
const api = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Intercepteur pour les requêtes
api.interceptors.request.use(
  (config) => {
    // Ajouter des headers d'authentification si nécessaire
    // const token = localStorage.getItem('token');
    // if (token) {
    //   config.headers.Authorization = `Bearer ${token}`;
    // }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Intercepteur pour les réponses
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Gestion globale des erreurs
    console.error('Erreur API:', error);
    
    if (error.response?.status === 401) {
      // Redirection vers login si nécessaire
      // window.location.href = '/login';
    }
    
    return Promise.reject(error);
  }
);

export default api;